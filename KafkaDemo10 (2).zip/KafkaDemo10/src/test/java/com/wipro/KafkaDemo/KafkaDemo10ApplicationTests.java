package com.wipro.KafkaDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KafkaDemo10ApplicationTests {

	@Test
	void contextLoads() {
	}

}
