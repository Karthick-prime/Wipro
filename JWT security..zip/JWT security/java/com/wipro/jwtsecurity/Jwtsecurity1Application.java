package com.wipro.jwtsecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jwtsecurity1Application {

    public static void main(String[] args) {
        SpringApplication.run(Jwtsecurity1Application.class, args);
    }

}
